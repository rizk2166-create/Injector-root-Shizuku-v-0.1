package com.rootinjector.app.core

import com.rootinjector.app.IShellService

// Berjalan di proses Shizuku (uid shell)
class ShellService : IShellService.Stub() {
    override fun destroy() { System.exit(0) }

    override fun exec(cmd: String): String = try {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText().trim()
        "${p.waitFor()}\n$out"
    } catch (e: Exception) {
        "-1\n${e.message}"
    }
}
