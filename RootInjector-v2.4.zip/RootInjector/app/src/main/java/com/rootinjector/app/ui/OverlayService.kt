package com.rootinjector.app.ui

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.rootinjector.app.core.MacroParser
import com.rootinjector.app.core.MacroRunner
import com.rootinjector.app.core.Shell
import com.rootinjector.app.core.ShellProvider
import kotlin.math.abs
import kotlin.math.hypot

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var panel: LinearLayout? = null
    private var statusView: TextView? = null
    private var recLayer: View? = null
    private var runner: MacroRunner? = null
    private var shell: Shell? = null
    private var pkg = ""
    private var label = ""
    private var useRoot = true

    override fun onBind(intent: Intent?): IBinder? = null

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun notif(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("ri", "Panel melayang", NotificationManager.IMPORTANCE_LOW))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "ri") else Notification.Builder(this)
        return b.setContentTitle("Injection panel active")
            .setContentText(label)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        pkg = intent?.getStringExtra("pkg") ?: ""
        label = intent?.getStringExtra("label") ?: pkg
        useRoot = intent?.getBooleanExtra("root", true) ?: true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(7, notif())
        removePanel()
        showPanel()
        return START_NOT_STICKY
    }

    private fun status(s: String) { main.post { statusView?.text = s } }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        panel = null
    }

    private fun showPanel() {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(12)
        lp.y = dp(160)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = shape(Ui.CARD, 18)
        root.setPadding(dp(8), dp(8), dp(8), dp(8))

        val head = tv("⚡ $label", 13f, Ui.TEXT, true)
        head.setPadding(dp(8), dp(6), dp(8), dp(6))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.visibility = View.GONE
        body.minimumWidth = dp(190)
        val st = tv("Ready", 12f, Ui.SUB)
        statusView = st
        body.addView(st)
        body.addView(btn("▶ Run", 1) { startMacro() })
        body.addView(btn("■ Stop") { runner?.stop() })
        body.addView(btn("● Record") { startRecord() })
        body.addView(btn("✕ Close", 2) { runner?.stop(); stopSelf() })

        root.addView(head)
        root.addView(body)

        head.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt()
                        val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        lp.x = sx + dx
                        lp.y = sy + dy
                        wm.updateViewLayout(root, lp)
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            body.visibility = if (body.visibility == View.GONE) View.VISIBLE else View.GONE
                            wm.updateViewLayout(root, lp)
                        }
                    }
                }
                return true
            }
        })

        wm.addView(root, lp)
        panel = root
    }

    private fun startMacro() {
        val text = getSharedPreferences("macros", MODE_PRIVATE).getString("macro_$pkg", "") ?: ""
        val macro = MacroParser.parse(text)
        if (macro.cmds.isEmpty()) { status("Panel has no steps"); return }
        if (macro.errors.isNotEmpty()) status("⚠ ${macro.errors.size} lines ignored")
        status("Connecting...")
        val go = { sh: Shell ->
            runner?.stop()
            val r = MacroRunner(sh, macro) { s -> status(s) }
            runner = r
            r.start()
        }
        val cached = shell
        if (cached != null) {
            go(cached)
        } else {
            ShellProvider.get(useRoot) { sh, err ->
                if (sh == null) status(err ?: "Connection failed")
                else { shell = sh; go(sh) }
            }
        }
    }

    private fun startRecord() {
        if (recLayer != null) return
        panel?.visibility = View.GONE
        val sb = StringBuilder("repeat 1\n")
        var count = 0
        var dx = 0f
        var dy = 0f
        var t0 = 0L
        var lastEnd = 0L

        val layer = FrameLayout(this)
        layer.setBackgroundColor(0x22000000)
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(0xCC000000.toInt())
        bar.setPadding(dp(10), dp(8), dp(10), dp(8))
        val info = tv("● REC — use the screen as usual", 13f, Color.WHITE, true)
        info.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        val done = btn("■ Done", 2) { }
        done.layoutParams = LinearLayout.LayoutParams(-2, -2)
        bar.addView(info)
        bar.addView(done)
        layer.addView(bar, FrameLayout.LayoutParams(-1, -2))

        layer.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX
                    dy = e.rawY
                    t0 = SystemClock.uptimeMillis()
                    if (lastEnd > 0L) {
                        val gap = t0 - lastEnd
                        if (gap > 50L) sb.append("wait ").append(gap).append('\n')
                    }
                }
                MotionEvent.ACTION_UP -> {
                    val now = SystemClock.uptimeMillis()
                    val ex = e.rawX
                    val ey = e.rawY
                    if (hypot(ex - dx, ey - dy) < dp(14).toFloat()) {
                        sb.append("tap ${dx.toInt()} ${dy.toInt()}\n")
                    } else {
                        val ms = (now - t0).coerceIn(80L, 2000L)
                        sb.append("swipe ${dx.toInt()} ${dy.toInt()} ${ex.toInt()} ${ey.toInt()} $ms\n")
                    }
                    lastEnd = now
                    count++
                    info.text = "● REC — $count actions"
                }
            }
            true
        }

        done.setOnClickListener {
            val prefs = getSharedPreferences("macros", MODE_PRIVATE)
            prefs.edit()
                .putString("macro_$pkg", sb.toString())
                .putBoolean("new_$pkg", true)
                .putString("name_$pkg", "New recording")
                .apply()
            try { wm.removeView(layer) } catch (e: Exception) { }
            recLayer = null
            panel?.visibility = View.VISIBLE
            status("Saved: $count actions")
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        wm.addView(layer, lp)
        recLayer = layer
    }

    override fun onDestroy() {
        runner?.stop()
        recLayer?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        removePanel()
        super.onDestroy()
    }
}
