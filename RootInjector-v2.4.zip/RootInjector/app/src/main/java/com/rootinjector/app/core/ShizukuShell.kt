package com.rootinjector.app.core

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.rootinjector.app.IShellService
import rikka.shizuku.Shizuku

class ShizukuShell(private val svc: IShellService) : Shell {
    fun alive() = svc.asBinder().pingBinder()

    override fun exec(cmd: String): ShellResult = try {
        val r = svc.exec(cmd)
        val i = r.indexOf('\n')
        if (i < 0) ShellResult(r.trim().toIntOrNull() ?: -1, "")
        else ShellResult(r.substring(0, i).toIntOrNull() ?: -1, r.substring(i + 1))
    } catch (e: Exception) {
        ShellResult(-1, e.message ?: "Shizuku error")
    }
}

object ShizukuConnector {
    private var cached: ShizukuShell? = null

    // onResult selalu dipanggil di main thread, tepat satu kali
    fun connect(onResult: (Shell?, String?) -> Unit) {
        cached?.let { if (it.alive()) { onResult(it, null); return } }
        if (!Shizuku.pingBinder()) {
            onResult(null, "Shizuku belum jalan. Buka app Shizuku lalu Start dulu."); return
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            val l = object : Shizuku.OnRequestPermissionResultListener {
                override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                    Shizuku.removeRequestPermissionResultListener(this)
                    if (grantResult == PackageManager.PERMISSION_GRANTED) bind(onResult)
                    else onResult(null, "Izin Shizuku ditolak.")
                }
            }
            Shizuku.addRequestPermissionResultListener(l)
            Shizuku.requestPermission(100)
            return
        }
        bind(onResult)
    }

    private fun bind(onResult: (Shell?, String?) -> Unit) {
        var delivered = false
        val handler = Handler(Looper.getMainLooper())
        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                val s = ShizukuShell(IShellService.Stub.asInterface(binder))
                cached = s
                if (!delivered) { delivered = true; onResult(s, null) }
            }
            override fun onServiceDisconnected(name: ComponentName) { cached = null }
        }
        handler.postDelayed({
            if (!delivered) { delivered = true; onResult(null, "Timeout menyambung ke layanan Shizuku. Coba restart Shizuku.") }
        }, 8000)
        try {
            val args = Shizuku.UserServiceArgs(
                ComponentName("com.rootinjector.app", ShellService::class.java.name)
            ).processNameSuffix("shell").version(1)
            Shizuku.bindUserService(args, conn)
        } catch (e: Throwable) {
            if (!delivered) { delivered = true; onResult(null, "Gagal bind Shizuku: ${e.message}") }
        }
    }
}
