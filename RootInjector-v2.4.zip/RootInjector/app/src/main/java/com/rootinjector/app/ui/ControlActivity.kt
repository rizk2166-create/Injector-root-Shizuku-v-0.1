package com.rootinjector.app.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import androidx.documentfile.provider.DocumentFile
import com.rootinjector.app.core.ActionEngine
import com.rootinjector.app.core.MacroParser
import com.rootinjector.app.core.RootShell
import com.rootinjector.app.core.Shell
import com.rootinjector.app.core.ShizukuConnector
import com.rootinjector.app.data.Config
import com.rootinjector.app.data.GameRepository
import com.rootinjector.app.data.PanelStore
import com.rootinjector.app.data.Target
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

class ControlActivity : Activity() {
    private val STORAGE = "/storage/emulated/0"

    private lateinit var pkg: String
    private lateinit var appLabel: String
    private lateinit var cfg: Config

    private lateinit var logView: TextView
    private lateinit var stagedView: TextView
    private lateinit var pathView: TextView
    private lateinit var targetSpinner: Spinner
    private lateinit var profileSpinner: Spinner
    private lateinit var subEdit: EditText
    private lateinit var scriptEdit: EditText
    private lateinit var lockCheck: CheckBox
    private lateinit var backupCheck: CheckBox
    private lateinit var stopCheck: CheckBox
    private lateinit var smartCheck: CheckBox
    private lateinit var macroEdit: EditText
    private lateinit var panelNameView: TextView
    private var panelPick = false
    private val MACRO_EXAMPLE = "# Contoh panel (hapus tanda # untuk aktifkan)\nrepeat 0\n# tap 540 1200\n# wait 500\n# swipe 300 1000 800 1000 200\n"
    private lateinit var zipCheck: CheckBox
    private lateinit var modeGroup: RadioGroup
    private var idShizuku = 0
    private var idRoot = 0
    private var profiles: List<String> = emptyList()

    private val ext: File get() = getExternalFilesDir(null) ?: filesDir
    private fun stagingDir(): File = File(ext, "staging").apply { mkdirs() }
    private fun profileRoot(): File = File(ext, "profiles/$pkg").apply { mkdirs() }
    private fun backupRoot(): String = File(ext, "backup").absolutePath
    private fun stagedFiles(): List<File> = stagingDir().walkTopDown().filter { it.isFile }.sortedBy { it.path }.toList()
    private fun rel(f: File): String = f.relativeTo(stagingDir()).path.replace(File.separatorChar, '/')
    private fun safeName(n: String): String = n.replace('/', '_').replace('\\', '_').ifBlank { "file" }
    private fun fmt(b: Long): String = when {
        b >= 1048576L -> "%.1f MB".format(b / 1048576.0)
        b >= 1024L -> "${b / 1024} KB"
        else -> "$b B"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pkg = intent.getStringExtra("pkg") ?: run { finish(); return }
        appLabel = intent.getStringExtra("label") ?: pkg
        cfg = GameRepository.loadConfig(this)
        window.statusBarColor = Ui.BG

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(8), dp(14), dp(28))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BG)
        scroll.fitsSystemWindows = true
        scroll.addView(col)
        setContentView(scroll)

        // ---- header ----
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(0, dp(8), 0, dp(4))
        val icon = ImageView(this)
        icon.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        try { icon.setImageDrawable(packageManager.getApplicationIcon(pkg)) } catch (e: Exception) { }
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(12), 0, 0, 0)
        titles.addView(tv(appLabel, 20f, Ui.TEXT, true))
        titles.addView(tv(pkg, 12f, Ui.SUB))
        header.addView(icon); header.addView(titles)
        col.addView(header)

        // ---- 1. mode ----
        val c1 = card("1 · MODE EKSEKUSI")
        idShizuku = View.generateViewId(); idRoot = View.generateViewId()
        modeGroup = RadioGroup(this)
        modeGroup.orientation = RadioGroup.HORIZONTAL
        val rbS = RadioButton(this); rbS.id = idShizuku; rbS.text = "Shizuku"; rbS.setTextColor(Ui.TEXT)
        val rbR = RadioButton(this); rbR.id = idRoot; rbR.text = "Root (su)"; rbR.setTextColor(Ui.TEXT)
        modeGroup.addView(rbS); modeGroup.addView(rbR)
        modeGroup.check(idRoot)
        c1.addView(modeGroup)
        c1.addView(row(
            btn("Tes koneksi") { withShell { sh -> val r = sh.exec("id"); log("✓ Terhubung → ${r.out}") } },
            btn("Diagnosa") {
                val d = fullDir(cfg.targets[targetSpinner.selectedItemPosition])
                val st = stagingDir().absolutePath
                withShell { ActionEngine(it, ::log).diagnose(pkg, d, st) }
            }
        ))
        col.addView(c1)

        // ---- 2. tujuan ----
        val c2 = card("2 · FOLDER TUJUAN")
        targetSpinner = Spinner(this)
        targetSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            cfg.targets.map { it.label.replace("{pkg}", pkg) })
        targetSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { updatePath() }
            override fun onNothingSelected(p: AdapterView<*>?) { }
        }
        c2.addView(targetSpinner)
        subEdit = edit("Subfolder (opsional), mis. files/UE4Game/Config")
        subEdit.doAfterTextChanged { updatePath() }
        c2.addView(subEdit)
        pathView = tv("", 11f, Ui.SUB)
        pathView.typeface = Typeface.MONOSPACE
        pathView.setTextIsSelectable(true)
        c2.addView(pathView)
        c2.addView(btn("📂 Jelajah folder tujuan (cari lokasi file game)") { browse(null) })
        col.addView(c2)

        // ---- 3. file ----
        val c3 = card("3 · FILE YANG MAU DIMASUKKAN")
        c3.addView(btn("📁 Ambil dari penyimpanan (ZArchiver / Download)", 1) { panelPick = false; storageBrowse("$STORAGE/Download") })
        c3.addView(row(btn("+ File (picker)") { pickFiles() }, btn("+ Folder (picker)") { pickFolder() }))
        val bundled = GameRepository.bundledMods(this, pkg)
        if (bundled.isNotEmpty()) c3.addView(btn("Tambah mod bawaan APK (${bundled.size})") { stageBundled(bundled) })
        zipCheck = CheckBox(this)
        zipCheck.text = "Ekstrak file .zip otomatis"
        zipCheck.setTextColor(Ui.TEXT)
        zipCheck.isChecked = true
        c3.addView(zipCheck)
        stagedView = tv("", 13f, Ui.TEXT)
        c3.addView(stagedView)
        c3.addView(row(btn("Kelola daftar") { manage() }, btn("Kosongkan", 2) { clearStaged() }))
        c3.addView(btn("🔍 Cek file rusak") { checkStagedUi() })
        col.addView(c3)

        // ---- 4. panel ----
        val c4 = card("4 · PAKET (file + script siap pakai)")
        c4.addView(tv("Paket = file + script + pengaturan. Mis. FPS Boost, Grafis HD, Grafis Kentang.", 12f, Ui.SUB))
        profileSpinner = Spinner(this)
        c4.addView(profileSpinner)
        c4.addView(row(btn("Simpan paket") { savePanel() }, btn("Muat") { loadPanel(false) }, btn("Hapus", 2) { deletePanel() }))
        c4.addView(btn("⚡ JALANKAN PAKET", 1) { confirmRunPanel() })
        col.addView(c4)

        // ---- 5. script ----
        val c5 = card("5 · SCRIPT SHELL (opsional)")
        scriptEdit = edit("Tulis script sh. Variabel: \$PKG \$TARGET \$STAGING \$STORAGE")
        scriptEdit.minLines = 4
        scriptEdit.gravity = Gravity.TOP
        scriptEdit.typeface = Typeface.MONOSPACE
        scriptEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        c5.addView(scriptEdit)
        c5.addView(row(btn("▶ Jalankan script") { runScriptNow() }, btn("Kosongkan") { scriptEdit.setText("") }))
        col.addView(c5)

        // ---- 6. aksi ----
        val c6 = card("6 · AKSI")
        stopCheck = CheckBox(this)
        stopCheck.text = "Force-stop app dulu (biar tidak menimpa balik)"
        stopCheck.setTextColor(Ui.TEXT)
        stopCheck.isChecked = true
        backupCheck = CheckBox(this)
        backupCheck.text = "Backup file asli dulu (bisa di-restore)"
        backupCheck.setTextColor(Ui.TEXT)
        backupCheck.isChecked = true
        lockCheck = CheckBox(this)
        lockCheck.text = "Kunci file setelah inject (anti ditimpa game)"
        lockCheck.setTextColor(Ui.TEXT)
        smartCheck = CheckBox(this)
        smartCheck.text = "Pintar: cari file asli di folder game & timpa di tempatnya (anti duplikat)"
        smartCheck.setTextColor(Ui.TEXT)
        smartCheck.isChecked = true
        c6.addView(smartCheck); c6.addView(stopCheck); c6.addView(backupCheck); c6.addView(lockCheck)
        c6.addView(btn("⚡ INJECT FILE", 1) { doInject(false) })
        c6.addView(row(btn("↩ Restore asli") { doRestore() }, btn("🔓 Buka kunci") { doUnlock() }))
        c6.addView(btn("🩺 Cek & perbaiki hasil inject") { doCheck() })
        c6.addView(btn("🗑 Hapus file hasil inject", 2) { confirmUninject() })
        c6.addView(row(btn("▶ Buka app") { openApp() }, btn("🧹 Hapus cache", 2) {
            AlertDialog.Builder(this).setTitle("Hapus cache $appLabel?")
                .setMessage(cfg.junk.joinToString("\n") { it.replace("{pkg}", pkg) })
                .setPositiveButton("Hapus") { _, _ -> doClean() }
                .setNegativeButton("Batal", null).show()
        }))
        col.addView(c6)

        // ---- 7. panel bot ----
        val cm = card("7 · PANEL BOT (auto play, panel melayang)")
        cm.addView(tv("Panel = daftar gerakan layar yang diulang. Pilih file panel, atau rekam sendiri lewat panel melayang (tombol ● Rekam).", 12f, Ui.SUB))
        cm.addView(btn("📂 Pilih file panel (ZArchiver / Download)", 1) { panelPick = true; storageBrowse("$STORAGE/Download") })
        panelNameView = tv("Panel aktif: (belum ada)", 13f, Ui.TEXT)
        cm.addView(panelNameView)
        macroEdit = edit("isi panel (gerakan layar), bisa diedit")
        macroEdit.minLines = 5
        macroEdit.gravity = Gravity.TOP
        macroEdit.typeface = Typeface.MONOSPACE
        macroEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        cm.addView(macroEdit)
        cm.addView(row(btn("Simpan panel") { saveMacro(true) }, btn("💾 Jadikan file") { exportPanelFile() }))
        cm.addView(row(btn("Contoh") { macroEdit.setText(MACRO_EXAMPLE) }, btn("Cek isi") { checkPanelText() }))
        cm.addView(btn("⚡ BUKA PANEL MELAYANG + GAME", 1) { startOverlay() })
        cm.addView(btn("📦 Save as Injection Panel") { saveAsPanel() })
        cm.addView(btn("Izin 'tampilkan di atas aplikasi lain'") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(cm)

        // ---- log ----
        val c7 = card("LOG")
        logView = tv("", 12f, Ui.TEXT)
        logView.typeface = Typeface.MONOSPACE
        logView.setTextIsSelectable(true)
        c7.addView(row(btn("Salin log") { copyLog() }, btn("Bersihkan") { logView.text = "" }))
        c7.addView(logView)
        col.addView(c7)

        updatePath()
        refreshStaged()
        refreshProfiles()
        macroEdit.setText(getSharedPreferences("macros", MODE_PRIVATE).getString("macro_$pkg", MACRO_EXAMPLE))
        panelNameView.text = "Panel aktif: " + (getSharedPreferences("macros", MODE_PRIVATE).getString("name_$pkg", null) ?: "(belum ada)")
    }

    // ---------------- util ----------------
    private fun log(s: String) {
        runOnUiThread { logView.append(s + "\n") }
        try { File(ext, "log.txt").appendText(s + "\n") } catch (e: Exception) { }
    }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("log", logView.text))
        Toast.makeText(this, "Log disalin", Toast.LENGTH_SHORT).show()
    }

    private fun openApp() {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i) else log("✗ Tidak bisa membuka $pkg")
    }

    private fun fullDir(t: Target): String {
        var d = t.path.replace("{pkg}", pkg)
        val sub = subEdit.text.toString().trim().trim('/')
        if (sub.isNotEmpty()) d += "/$sub"
        return d
    }

    private fun updatePath() {
        if (!::pathView.isInitialized || !::subEdit.isInitialized || !::targetSpinner.isInitialized) return
        val t = cfg.targets.getOrNull(targetSpinner.selectedItemPosition) ?: return
        pathView.text = fullDir(t)
    }

    private fun resolveDir(): String? {
        val t = cfg.targets[targetSpinner.selectedItemPosition]
        if (t.needsRoot && modeGroup.checkedRadioButtonId != idRoot) {
            log("✗ Folder ini butuh mode Root."); return null
        }
        return fullDir(t)
    }

    private fun refreshStaged() {
        runOnUiThread {
            val fs = stagedFiles()
            stagedView.text = if (fs.isEmpty()) "Belum ada file dipilih"
            else "${fs.size} file • ${fmt(fs.sumOf { it.length() })}\n" +
                fs.take(8).joinToString("\n") { "• " + rel(it) } +
                (if (fs.size > 8) "\n… +${fs.size - 8} lagi" else "")
        }
    }

    // ---------------- shell ----------------
    private fun withShell(action: (Shell) -> Unit) {
        if (modeGroup.checkedRadioButtonId == idRoot) {
            Thread {
                val sh = RootShell()
                val r = sh.exec("id")
                if (r.code == 0 && r.out.contains("uid=0")) {
                    try { action(sh) } catch (e: Throwable) { log("✗ Error: ${e.message}") }
                } else log("✗ Root tidak tersedia / izin su belum diberikan: ${r.out}")
            }.start()
        } else {
            ShizukuConnector.connect { sh, err ->
                if (sh == null) log("✗ ${err ?: "Shizuku gagal"}")
                else Thread {
                    try { action(sh) } catch (e: Throwable) { log("✗ Error: ${e.message}") }
                }.start()
            }
        }
    }

    // ---------------- ambil dari penyimpanan (ZArchiver, Download, dll) ----------------
    private fun storageBrowse(dir: String) {
        if (!dir.startsWith(STORAGE) || dir.contains("..")) { log("✗ Di luar penyimpanan: $dir"); return }
        withShell { sh ->
            val res = ActionEngine(sh, ::log).listDir(dir)
            if (res == null) { log("✗ Tidak bisa membuka $dir"); return@withShell }
            val dirs = res.first
            val files = res.second
            val items = (listOf("⬆ Naik satu level", "✔ Ambil folder ini (utuh)", "✔ Ambil semua FILE di sini")
                + dirs.map { "📁 $it" } + files.map { "📄 $it" }).toTypedArray()
            runOnUiThread {
                AlertDialog.Builder(this).setTitle(dir.removePrefix(STORAGE).ifEmpty { "/" })
                    .setItems(items) { _, which ->
                        if (which == 0) {
                            val parent = dir.substringBeforeLast('/')
                            storageBrowse(if (parent.length < STORAGE.length) dir else parent)
                        } else if (which == 1) {
                            addFromStorage(listOf(dir), dir)
                        } else if (which == 2) {
                            addFromStorage(files.map { "$dir/$it" }, dir)
                        } else if (which < 3 + dirs.size) {
                            storageBrowse("$dir/${dirs[which - 3]}")
                        } else {
                            val fn = files[which - 3 - dirs.size]
                            if (panelPick) { panelPick = false; loadPanelFile(dir, fn) } else fileTap(dir, fn)
                        }
                    }
                    .setNegativeButton("Tutup", null).show()
            }
        }
    }

    private fun fileTap(dir: String, name: String) {
        val lower = name.lowercase()
        val isScript = lower.endsWith(".sh") || lower.endsWith(".txt")
        val opts = if (isScript) arrayOf("Tambah ke daftar file", "Muat sebagai script") else arrayOf("Tambah ke daftar file")
        AlertDialog.Builder(this).setTitle(name).setItems(opts) { _, w ->
            if (w == 0) addFromStorage(listOf("$dir/$name"), dir)
            else withShell { sh ->
                val text = ActionEngine(sh, ::log).readFile("$dir/$name")
                runOnUiThread { scriptEdit.setText(text); log("✓ Script dimuat: $name") }
            }
        }.setNegativeButton("Batal") { _, _ -> storageBrowse(dir) }.show()
    }

    private fun addFromStorage(srcs: List<String>, again: String) {
        if (panelPick) { log("Mode pilih file panel: tekan file panelnya saja."); storageBrowse(again); return }
        if (srcs.isEmpty()) { log("Tidak ada file."); storageBrowse(again); return }
        val zip = zipCheck.isChecked
        val st = stagingDir().absolutePath
        withShell { sh ->
            val eng = ActionEngine(sh, ::log)
            for (s in srcs) {
                val r = eng.copyIn(s, st)
                if (r.code != 0) log("✗ ${s.substringAfterLast('/')}: ${r.out}")
            }
            eng.openStaging(st)
            if (zip) {
                for (s in srcs) {
                    val n = s.substringAfterLast('/')
                    if (n.lowercase().endsWith(".zip")) {
                        val f = File(stagingDir(), n)
                        try {
                            if (f.isFile) { f.inputStream().use { unzip(it, stagingDir()) }; f.delete(); log("  ekstrak $n") }
                        } catch (e: Exception) { log("✗ zip $n: ${e.message}") }
                    }
                }
            }
            refreshStaged()
            log("✓ ${srcs.size} item ditambahkan")
            runOnUiThread { storageBrowse(again) }
        }
    }

    // ---------------- pilih file (picker sistem) ----------------
    private fun pickFiles() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }, 1)
    }

    private fun pickFolder() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val zip = zipCheck.isChecked
        if (requestCode == 1) {
            val uris = LinkedHashSet<Uri>()
            data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
            data.data?.let { uris.add(it) }
            Thread {
                for (u in uris) importUri(u, zip)
                refreshStaged()
                log("✓ ${uris.size} item ditambahkan")
            }.start()
        } else if (requestCode == 2) {
            val tree = data.data ?: return
            Thread {
                try {
                    val d = DocumentFile.fromTreeUri(this, tree)
                    if (d != null) copyTree(d, File(stagingDir(), safeName(d.name ?: "folder")))
                    log("✓ Folder ditambahkan: ${d?.name}")
                } catch (e: Exception) { log("✗ Folder: ${e.message}") }
                refreshStaged()
            }.start()
        }
    }

    private fun importUri(u: Uri, zip: Boolean) {
        var name = "file"
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = c.getString(i)
            }
        }
        name = safeName(name)
        try {
            if (zip && name.lowercase().endsWith(".zip")) {
                contentResolver.openInputStream(u)?.use { unzip(it, stagingDir()) }
                log("  ekstrak $name")
            } else {
                val out = File(stagingDir(), name)
                contentResolver.openInputStream(u)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            }
        } catch (e: Exception) { log("✗ $name: ${e.message}") }
    }

    private fun unzip(input: InputStream, dest: File) {
        val base = dest.canonicalPath
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val out = File(dest, e.name)
                if (!out.canonicalPath.startsWith(base + File.separator)) {
                    log("  lewati entri tidak aman: ${e.name}")
                } else if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { o -> z.copyTo(o) }
                }
                e = z.nextEntry
            }
        }
    }

    private fun copyTree(src: DocumentFile, dst: File) {
        if (src.isDirectory) {
            dst.mkdirs()
            for (c in src.listFiles()) copyTree(c, File(dst, safeName(c.name ?: "x")))
        } else {
            contentResolver.openInputStream(src.uri)?.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    private fun stageBundled(names: List<String>) {
        Thread {
            for (n in names) {
                try { copyAsset("mods/$pkg/$n", File(stagingDir(), n)) }
                catch (e: Exception) { log("✗ $n: ${e.message}") }
            }
            refreshStaged()
            log("✓ Mod bawaan ditambahkan")
        }.start()
    }

    private fun copyAsset(path: String, dest: File) {
        val kids = assets.list(path)
        if (kids != null && kids.isNotEmpty()) {
            dest.mkdirs()
            for (k in kids) copyAsset("$path/$k", File(dest, k))
        } else {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    private fun clearStaged() {
        Thread { stagingDir().deleteRecursively(); refreshStaged(); log("Daftar file dikosongkan") }.start()
    }

    private fun manage() {
        val files = stagedFiles()
        if (files.isEmpty()) { log("Daftar kosong."); return }
        val names = files.map { rel(it) }.toTypedArray()
        val checked = BooleanArray(files.size) { true }
        AlertDialog.Builder(this).setTitle("Centang file yang dipakai")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Terapkan") { _, _ ->
                files.forEachIndexed { i, f -> if (!checked[i]) f.delete() }
                val root = stagingDir()
                root.walkBottomUp().toList()
                    .filter { it.isDirectory && it != root && it.list().isNullOrEmpty() }
                    .forEach { it.delete() }
                refreshStaged()
            }
            .setNegativeButton("Batal", null).show()
    }

    // ---------------- panel ----------------
    private fun refreshProfiles() {
        profiles = profileRoot().listFiles()?.filter { it.isDirectory }?.map { it.name }?.sorted() ?: emptyList()
        profileSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            if (profiles.isEmpty()) listOf("(belum ada paket)") else profiles)
    }

    private fun selectedProfile(): String? = profiles.getOrNull(profileSpinner.selectedItemPosition)

    private fun savePanel() {
        val script = scriptEdit.text.toString()
        if (stagedFiles().isEmpty() && script.isBlank()) { log("✗ Isi file atau script dulu."); return }
        val et = EditText(this)
        et.hint = "Nama paket, mis. FPS Boost"
        AlertDialog.Builder(this).setTitle("Simpan paket").setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val name = et.text.toString().trim().replace(Regex("[^A-Za-z0-9_-]"), "_")
                if (name.isNotEmpty()) {
                    val meta = JSONObject()
                        .put("sub", subEdit.text.toString().trim())
                        .put("script", script)
                        .put("target", targetSpinner.selectedItemPosition)
                        .put("lock", lockCheck.isChecked)
                        .put("stop", stopCheck.isChecked)
                    Thread {
                        val d = File(profileRoot(), name)
                        d.deleteRecursively()
                        val fd = File(d, "files")
                        fd.mkdirs()
                        stagingDir().copyRecursively(fd, true)
                        File(d, "panel.json").writeText(meta.toString())
                        runOnUiThread { refreshProfiles() }
                        log("✓ Paket '$name' disimpan")
                    }.start()
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun loadPanel(thenRun: Boolean) {
        val name = selectedProfile() ?: run { log("✗ Belum ada paket."); return }
        Thread {
            val d = File(profileRoot(), name)
            stagingDir().deleteRecursively()
            val fd = File(d, "files")
            val src = if (fd.exists()) fd else d
            src.copyRecursively(stagingDir(), true)
            stagingDir().walkTopDown().filter { it.isFile && it.name == "panel.json" && it.parentFile == stagingDir() }.forEach { it.delete() }
            val mf = File(d, "panel.json")
            val meta = if (mf.exists()) JSONObject(mf.readText()) else null
            runOnUiThread {
                if (meta != null) {
                    subEdit.setText(meta.optString("sub"))
                    scriptEdit.setText(meta.optString("script"))
                    val pos = meta.optInt("target", 0)
                    if (pos in 0 until cfg.targets.size) targetSpinner.setSelection(pos)
                    lockCheck.isChecked = meta.optBoolean("lock", false)
                    stopCheck.isChecked = meta.optBoolean("stop", true)
                }
                refreshStaged()
                log("✓ Paket '$name' dimuat")
                if (thenRun) doInject(true)
            }
        }.start()
    }

    private fun confirmRunPanel() {
        val name = selectedProfile() ?: run { log("✗ Belum ada paket."); return }
        AlertDialog.Builder(this).setTitle("Jalankan paket '$name'?")
            .setMessage("File paket akan dimasukkan ke $appLabel, lalu script paket (kalau ada) dijalankan.")
            .setPositiveButton("Jalankan") { _, _ -> loadPanel(true) }
            .setNegativeButton("Batal", null).show()
    }

    private fun deletePanel() {
        val name = selectedProfile() ?: run { log("✗ Belum ada paket."); return }
        AlertDialog.Builder(this).setTitle("Hapus paket '$name'?")
            .setPositiveButton("Hapus") { _, _ ->
                File(profileRoot(), name).deleteRecursively()
                refreshProfiles()
                log("Paket '$name' dihapus")
            }
            .setNegativeButton("Batal", null).show()
    }

    // ---------------- jelajah folder tujuan ----------------
    private fun browse(subArg: String?) {
        val t = cfg.targets[targetSpinner.selectedItemPosition]
        if (t.needsRoot && modeGroup.checkedRadioButtonId != idRoot) { log("✗ Folder ini butuh mode Root."); return }
        val base = t.path.replace("{pkg}", pkg)
        val cur = subArg ?: subEdit.text.toString().trim().trim('/')
        val dir = if (cur.isEmpty()) base else "$base/$cur"
        withShell { sh ->
            val eng = ActionEngine(sh, ::log)
            if (!eng.isSafe(dir, pkg)) { log("✗ Path ditolak: $dir"); return@withShell }
            val res = eng.listDir(dir)
            if (res == null) { log("✗ Tidak bisa membuka $dir (folder belum ada?)"); return@withShell }
            val dirs = res.first
            val files = res.second
            val items = (listOf("⬆ Naik satu level", "✔ PILIH folder ini")
                + dirs.map { "📁 $it" } + files.map { "📄 $it" }).toTypedArray()
            runOnUiThread {
                AlertDialog.Builder(this).setTitle(dir.removePrefix(STORAGE))
                    .setItems(items) { _, which ->
                        if (which == 0) browse(cur.substringBeforeLast('/', ""))
                        else if (which == 1) subEdit.setText(cur)
                        else if (which < 2 + dirs.size) {
                            val d = dirs[which - 2]
                            browse(if (cur.isEmpty()) d else "$cur/$d")
                        } else browse(cur)
                    }
                    .setNegativeButton("Tutup", null).show()
            }
        }
    }

    // ---------------- aksi ----------------
    private fun doInject(withScript: Boolean) {
        val files = stagedFiles()
        val script = scriptEdit.text.toString().trim()
        val runScript = withScript && script.isNotEmpty()
        if (files.isEmpty() && !runScript) { log("✗ Pilih file dulu."); return }
        val problems = findProblems(files)
        if (problems.isNotEmpty()) {
            val msg = problems.entries.joinToString("\n") { "• ${it.key.name}: ${it.value}" }
            AlertDialog.Builder(this).setTitle("File bermasalah terdeteksi")
                .setMessage(msg + "\n\nLewati file bermasalah dan inject yang lain?")
                .setPositiveButton("Lanjut tanpa itu") { _, _ ->
                    injectNow(files.filter { it !in problems.keys }, withScript)
                }
                .setNegativeButton("Batal", null).show()
            return
        }
        injectNow(files, withScript)
    }

    private fun injectNow(files: List<File>, withScript: Boolean) {
        val script = scriptEdit.text.toString().trim()
        val runScript = withScript && script.isNotEmpty()
        if (files.isEmpty() && !runScript) { log("✗ Tidak ada file valid untuk di-inject."); return }
        val dir = resolveDir() ?: return
        val root = stagingDir()
        val st = root.absolutePath
        val lock = lockCheck.isChecked
        val stop = stopCheck.isChecked
        val smart = smartCheck.isChecked
        val bk = if (backupCheck.isChecked) backupRoot() else null
        val manifest = File(ext, "injected/$pkg.txt")
        log(if (files.isEmpty()) "→ Jalankan script" else "→ Inject ${files.size} file ke $appLabel")
        withShell { sh ->
            val eng = ActionEngine(sh, ::log)
            if (stop) { sh.exec("am force-stop $pkg"); log("  app di-force stop") }
            if (files.isNotEmpty()) {
                val done = eng.inject(pkg, dir, root, files, lock, bk, smart)
                if (done.isNotEmpty()) {
                    manifest.parentFile?.mkdirs()
                    val old = if (manifest.exists()) manifest.readLines() else emptyList()
                    val map = LinkedHashMap<String, String>()
                    (old + done).filter { it.isNotBlank() }.forEach { map[it.substringBefore('\t')] = it }
                    manifest.writeText(map.values.joinToString("\n") + "\n")
                }
            }
            if (runScript) eng.runScript(pkg, dir, st, script)
        }
    }

    private fun confirmUninject() {
        val manifest = File(ext, "injected/$pkg.txt")
        val paths = (if (manifest.exists()) manifest.readLines() else emptyList()).filter { it.isNotBlank() }.map { it.substringBefore('\t') }
        if (paths.isEmpty()) { log("Belum ada file hasil inject yang tercatat."); return }
        val preview = paths.take(10).joinToString("\n") { it.substringAfterLast('/') } +
            (if (paths.size > 10) "\n…" else "")
        AlertDialog.Builder(this).setTitle("Hapus ${paths.size} file hasil inject?")
            .setMessage(preview + "\n\nFile asli dipulihkan dari backup kalau ada.")
            .setPositiveButton("Hapus") { _, _ ->
                val bk = backupRoot()
                withShell { sh ->
                    ActionEngine(sh, ::log).uninject(pkg, paths, bk)
                    manifest.delete()
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    // ---------------- macro / panel melayang ----------------
    private fun saveMacro(show: Boolean) {
        getSharedPreferences("macros", MODE_PRIVATE).edit()
            .putString("macro_$pkg", macroEdit.text.toString())
            .putBoolean("root", modeGroup.checkedRadioButtonId == idRoot)
            .apply()
        if (show) log("✓ Panel disimpan")
    }

    private fun startOverlay() {
        saveMacro(false)
        if (!Settings.canDrawOverlays(this)) {
            log("✗ Izin 'tampilkan di atas aplikasi lain' belum aktif. Aktifkan, lalu kembali ke sini dan tekan lagi.")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java)
            .putExtra("pkg", pkg)
            .putExtra("label", appLabel)
            .putExtra("root", modeGroup.checkedRadioButtonId == idRoot)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        log("✓ Panel melayang aktif. Di game, tekan ikon ⚡ untuk membuka panel.")
        openApp()
    }

    override fun onResume() {
        super.onResume()
        if (!::macroEdit.isInitialized) return
        val p = getSharedPreferences("macros", MODE_PRIVATE)
        if (p.getBoolean("new_$pkg", false)) {
            macroEdit.setText(p.getString("macro_$pkg", "") ?: "")
            p.edit().putBoolean("new_$pkg", false).apply()
            panelNameView.text = "Panel aktif: " + (p.getString("name_$pkg", "rekaman") ?: "rekaman")
            log("✓ Panel hasil rekam dimuat")
        }
    }

    private fun runScriptNow() {
        val s = scriptEdit.text.toString().trim()
        if (s.isEmpty()) { log("✗ Script kosong."); return }
        val dir = fullDir(cfg.targets[targetSpinner.selectedItemPosition])
        val st = stagingDir().absolutePath
        val mode = if (modeGroup.checkedRadioButtonId == idRoot) "Root" else "Shizuku"
        AlertDialog.Builder(this).setTitle("Jalankan script?")
            .setMessage("Script jalan dengan hak akses $mode tanpa batasan. Pastikan kamu paham isinya.\n\n" + s.take(600))
            .setPositiveButton("Jalankan") { _, _ ->
                log("▶ Menjalankan script...")
                withShell { ActionEngine(it, ::log).runScript(pkg, dir, st, s) }
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun doRestore() {
        val dir = resolveDir() ?: return
        withShell { ActionEngine(it, ::log).restore(pkg, dir, backupRoot()) }
    }

    private fun doUnlock() {
        val dir = resolveDir() ?: return
        withShell { ActionEngine(it, ::log).unlock(pkg, dir) }
    }

    private fun doClean() {
        val paths = cfg.junk.map { it.replace("{pkg}", pkg) }
            .filter { modeGroup.checkedRadioButtonId == idRoot || !it.startsWith("/data/") }
        withShell { ActionEngine(it, ::log).clean(pkg, paths) }
    }

    // ---------------- file panel ----------------
    private fun loadPanelFile(dir: String, name: String) {
        withShell { sh ->
            val text = ActionEngine(sh, ::log).readFile("$dir/$name")
            val m = MacroParser.parse(text)
            runOnUiThread {
                if (m.cmds.isEmpty()) {
                    log("✗ $name bukan file panel yang valid (tidak ada baris tap / swipe / wait)")
                } else {
                    macroEdit.setText(text)
                    panelNameView.text = "Panel aktif: $name"
                    saveMacro(false)
                    getSharedPreferences("macros", MODE_PRIVATE).edit().putString("name_$pkg", name).apply()
                    log("✓ Panel dimuat: $name (${m.cmds.size} gerakan" +
                        (if (m.errors.isNotEmpty()) ", ${m.errors.size} baris diabaikan)" else ")"))
                }
            }
        }
    }

    private fun exportPanelFile() {
        val text = macroEdit.text.toString()
        if (MacroParser.parse(text).cmds.isEmpty()) { log("✗ Panel masih kosong."); return }
        val et = EditText(this)
        et.hint = "Nama file panel, mis. blockblast"
        AlertDialog.Builder(this).setTitle("Simpan jadi file panel").setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val n = et.text.toString().trim().replace(Regex("[^A-Za-z0-9_-]"), "_")
                if (n.isNotEmpty()) {
                    val f = File(File(ext, "panels").apply { mkdirs() }, "$n.panel")
                    f.writeText(text)
                    withShell { sh ->
                        val eng = ActionEngine(sh, ::log)
                        val dl = eng.qp("$STORAGE/Download")
                        val r = sh.exec("mkdir -p $dl && cp -f ${eng.qp(f.absolutePath)} $dl/")
                        log(if (r.code == 0) "✓ Tersimpan: Download/$n.panel"
                        else "✓ Tersimpan di app: ${f.absolutePath} (salin ke Download gagal: ${r.out})")
                    }
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun checkPanelText() {
        val m = MacroParser.parse(macroEdit.text.toString())
        log("Panel: ${m.cmds.size} gerakan, ulang ${if (m.repeat == 0) "terus-menerus" else "${m.repeat}x"}")
        for (e in m.errors) log("  ⚠ baris tidak dikenali: $e")
    }

    // ---------------- deteksi file rusak ----------------
    private fun findProblems(files: List<File>): Map<File, String> {
        val out = LinkedHashMap<File, String>()
        for (f in files) {
            if (f.length() == 0L) { out[f] = "kosong (0 byte)"; continue }
            val n = f.name.lowercase()
            if (n.endsWith(".zip") || n.endsWith(".apk") || n.endsWith(".jar")) {
                try {
                    java.util.zip.ZipFile(f).use { }
                } catch (e: Exception) {
                    out[f] = "arsip rusak / terpotong (${e.message})"
                }
            }
        }
        return out
    }

    private fun checkStagedUi() {
        val files = stagedFiles()
        if (files.isEmpty()) { log("Daftar file kosong."); return }
        val p = findProblems(files)
        if (p.isEmpty()) log("✓ ${files.size} file terlihat sehat")
        else for ((f, m) in p) log("✗ ${f.name}: $m")
    }

    private fun doCheck() {
        val manifest = File(ext, "injected/$pkg.txt")
        val entries = if (manifest.exists()) manifest.readLines().filter { it.isNotBlank() } else emptyList()
        if (entries.isEmpty()) { log("Belum ada file hasil inject yang tercatat."); return }
        val root = stagingDir()
        val files = stagedFiles()
        val bk = if (backupCheck.isChecked) backupRoot() else null
        log("→ Cek ${entries.size} file hasil inject...")
        withShell { ActionEngine(it, ::log).checkInjected(pkg, entries, root, files, bk) }
    }

    private fun saveAsPanel() {
        val text = macroEdit.text.toString()
        if (MacroParser.parse(text).cmds.isEmpty()) { log("✗ Panel has no steps"); return }
        val et = EditText(this)
        et.hint = "Panel name"
        AlertDialog.Builder(this).setTitle("Save as Injection Panel").setView(et)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().trim().ifEmpty { "$appLabel Bot" }
                val d = PanelStore.newDir(this, n)
                val j = JSONObject().put("name", n).put("icon", "🤖").put("target", pkg).put("steps", text)
                File(d, PanelStore.MANIFEST).writeText(j.toString(2))
                log("✓ Saved to Injection Panel: $n")
            }
            .setNegativeButton("Cancel", null).show()
    }
}
