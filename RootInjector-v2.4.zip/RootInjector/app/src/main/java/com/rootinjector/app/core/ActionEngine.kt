package com.rootinjector.app.core

import java.io.File

class ActionEngine(private val sh: Shell, private val log: (String) -> Unit) {

    companion object {
        fun quote(s: String) = "'" + s.replace("'", "'\\''") + "'"
    }

    // Root sering punya mount namespace berbeda: /storage/emulated/0 bisa tidak ada.
    // Deteksi otomatis lokasi penyimpanan yang benar-benar terlihat oleh shell.
    private val base: String by lazy {
        var found = "/storage/emulated/0"
        for (c in listOf("/storage/emulated/0", "/sdcard", "/data/media/0")) {
            if (sh.exec("[ -d ${quote("$c/Android")} ] && echo ok").out.contains("ok")) { found = c; break }
        }
        found
    }

    private fun m(p: String) =
        if (p.startsWith("/storage/emulated/0")) base + p.removePrefix("/storage/emulated/0") else p

    private fun q(s: String) = quote(m(s))
    fun qp(s: String) = q(s)

    // Hanya boleh menyentuh folder milik paket target
    fun isSafe(path: String, pkg: String): Boolean {
        if (path.contains("..") || path.contains('\n')) return false
        val roots = listOf(
            "/storage/emulated/0/Android/data/$pkg",
            "/storage/emulated/0/Android/obb/$pkg",
            "/data/data/$pkg",
            "/data/user/0/$pkg"
        )
        return roots.any { path == it || path.startsWith("$it/") }
    }

    fun listDir(dir: String): Pair<List<String>, List<String>>? {
        val cmd = "cd ${q(dir)} 2>/dev/null || exit 3; " +
            "for f in * .[!.]* ..?*; do " +
            "if [ -d \"\$f\" ]; then echo \"\$f/\"; elif [ -e \"\$f\" ]; then echo \"\$f\"; fi; done"
        val r = sh.exec(cmd)
        if (r.code != 0) return null
        val names = r.out.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val dirs = names.filter { it.endsWith("/") }.map { it.trimEnd('/') }.sorted()
        val files = names.filter { !it.endsWith("/") }.sorted()
        return Pair(dirs, files)
    }

    fun readFile(path: String): String = sh.exec("cat ${q(path)}").out

    fun copyIn(src: String, stagingDir: String): ShellResult =
        sh.exec("mkdir -p ${q(stagingDir)}; cp -rf ${q(src)} ${q(stagingDir)}/")

    fun openStaging(stagingDir: String) {
        sh.exec("chmod -R 777 ${q(stagingDir)}")
    }

    private fun u(p: String): String =
        if (base != "/storage/emulated/0" && p.startsWith(base)) "/storage/emulated/0" + p.removePrefix(base) else p

    // Cari file bernama sama di dalam folder data/obb/internal milik game
    private fun findByName(pkg: String, name: String): List<String> {
        val roots = listOf(
            "/storage/emulated/0/Android/data/$pkg",
            "/storage/emulated/0/Android/obb/$pkg",
            "/data/data/$pkg"
        )
        val out = ArrayList<String>()
        for (r in roots) {
            val res = sh.exec("find ${q(r)} -type f -name ${quote(name)} 2>/dev/null")
            res.out.lines().map { it.trim() }.filter { it.startsWith("/") }.forEach { out.add(u(it)) }
        }
        return out.distinct()
    }

    fun inject(
        pkg: String, dir: String, root: File, files: List<File>,
        lock: Boolean, backupRoot: String?, smart: Boolean
    ): List<String> {
        val done = ArrayList<String>()
        if (!isSafe(dir, pkg)) { log("✗ Path ditolak (bukan folder milik $pkg): $dir"); return done }
        val mk = sh.exec("mkdir -p ${q(dir)}")
        if (mk.code != 0) { log("✗ Gagal buat folder: ${mk.out}"); return done }

        val internal = dir.startsWith("/data/") || base.startsWith("/data/media")
        val uid = sh.exec("stat -c %u ${q("/data/data/$pkg")}").out.trim()
            .takeIf { it.isNotEmpty() && it.all(Char::isDigit) }

        val cache = HashMap<String, List<String>>()
        val tops = LinkedHashSet<String>()
        var ok = 0
        var bad = 0

        fun put(f: File, rel: String, dst: String) {
            if (f.length() == 0L) { log("✗ ${f.name}: file kosong (0 byte), dilewati"); bad++; return }
            val existed = sh.exec("[ -e ${q(dst)} ] && echo ya").out.contains("ya")
            val dstDir = dst.substringBeforeLast('/')
            sh.exec("mkdir -p ${q(dstDir)}")
            val names = cache.getOrPut(dstDir) {
                listDir(dstDir)?.let { it.first + it.second } ?: emptyList()
            }
            if (backupRoot != null) {
                val b = backupRoot + dst
                sh.exec("if [ -e ${q(dst)} ] && [ ! -e ${q(b)} ]; then mkdir -p ${q(b.substringBeforeLast('/'))} && cp -f ${q(dst)} ${q(b)}; fi")
            }
            val baseName = f.nameWithoutExtension
            val ext = if (f.extension.isEmpty()) "" else "." + f.extension
            val dup = Regex("^" + Regex.escape(baseName) + "( \\(\\d+\\)|_copy\\d*|-\\d+)?" + Regex.escape(ext) + "$")
            names.filter { dup.matches(it) }.forEach { n ->
                val p = q("$dstDir/$n")
                sh.exec("chattr -i $p 2>/dev/null; chmod 666 $p 2>/dev/null; rm -rf $p")
                log("  hapus lama/duplikat: $n")
            }
            val srcSum = sha(f.absolutePath)
            var attempt = 0
            var good = false
            while (attempt < 3 && !good) {
                attempt++
                val r = sh.exec("cp -f ${q(f.absolutePath)} ${q(dst)} && chmod 644 ${q(dst)}")
                if (r.code != 0) {
                    log("  ⚠ percobaan $attempt gagal: ${hint(r.out)}")
                    continue
                }
                val a = sh.exec("stat -c %s ${q(f.absolutePath)}").out.trim()
                val c = sh.exec("stat -c %s ${q(dst)}").out.trim()
                val dstSum = sha(dst)
                good = if (srcSum.isNotEmpty() && dstSum.isNotEmpty()) srcSum == dstSum else (a.isNotEmpty() && a == c)
                if (!good) log("  ⚠ percobaan $attempt: hasil tidak cocok ($a vs $c byte), ulangi")
            }
            if (!good) {
                bad++
                val bkp = if (backupRoot != null) backupRoot + dst else null
                val restored = bkp != null &&
                    sh.exec("[ -e ${q(bkp)} ] && cp -f ${q(bkp)} ${q(dst)} && echo ok").out.contains("ok")
                if (restored) {
                    log("✗ ${f.name}: gagal, file asli dikembalikan dari backup")
                } else if (!existed) {
                    sh.exec("rm -f ${q(dst)}")
                    log("✗ ${f.name}: gagal setelah 3 percobaan, file setengah jadi dibuang")
                } else {
                    log("✗ ${f.name}: gagal & file asli sudah tertimpa. Aktifkan Backup supaya bisa di-restore")
                }
                return
            }
            log("✓ ${f.name} → ${dst.removePrefix("/storage/emulated/0")}")
            ok++
            done.add(dst + "\t" + srcSum)
            if (uid != null && (dst.startsWith("/data/") || base.startsWith("/data/media"))) {
                sh.exec("chown $uid:$uid ${q(dst)}")
            }
            if (lock) sh.exec("chmod 444 ${q(dst)}; chattr +i ${q(dst)} 2>/dev/null")
        }

        for (f in files) {
            val rel = f.relativeTo(root).path.replace(File.separatorChar, '/')
            val relDir = rel.substringBeforeLast('/', "")
            val defaultDst = (if (relDir.isEmpty()) dir else "$dir/$relDir") + "/" + f.name
            var targets = listOf(defaultDst)
            if (smart) {
                val found = findByName(pkg, f.name).filter { isSafe(it, pkg) }
                if (found.isNotEmpty() && found.size <= 5) {
                    targets = found
                    log("  🔎 ${f.name}: ketemu ${found.size} lokasi asli, ditimpa di tempatnya")
                } else if (found.size > 5) {
                    log("  ⚠ ${f.name}: ketemu ${found.size} lokasi (terlalu banyak), pakai folder tujuan")
                }
            }
            if (targets.size == 1 && targets[0] == defaultDst) tops.add(rel.substringBefore('/'))
            targets.forEach { put(f, rel, it) }
        }
        if (internal) {
            tops.forEach { t ->
                if (uid != null) sh.exec("chown -R $uid:$uid ${q("$dir/$t")}")
                sh.exec("restorecon -R ${q("$dir/$t")} 2>/dev/null")
            }
        }
        if (lock) log("🔒 file dikunci")
        log("Selesai: $ok berhasil, $bad gagal")
        return done
    }

    // Hapus file hasil inject; kalau ada backup asli, dipulihkan
    fun uninject(pkg: String, paths: List<String>, backupRoot: String) {
        var n = 0
        for (p in paths) {
            if (!isSafe(p, pkg)) { log("✗ lewati (tidak aman): $p"); continue }
            sh.exec("chattr -i ${q(p)} 2>/dev/null; chmod 666 ${q(p)} 2>/dev/null; rm -f ${q(p)}")
            val b = backupRoot + p
            val restored = sh.exec("[ -e ${q(b)} ] && cp -f ${q(b)} ${q(p)} && echo restored").out.contains("restored")
            log(if (restored) "↩ dipulihkan: ${p.substringAfterLast('/')}" else "✓ dihapus: ${p.substringAfterLast('/')}")
            n++
        }
        log("Selesai: $n file")
    }

    private fun sha(path: String): String {
        val h = sh.exec("sha256sum ${q(path)} 2>/dev/null").out.trim().substringBefore(' ')
        if (h.length == 64) return h
        val m = sh.exec("md5sum ${q(path)} 2>/dev/null").out.trim().substringBefore(' ')
        return if (m.length == 32) m else ""
    }

    private fun hint(out: String): String {
        val o = out.lowercase()
        val h = when {
            "permission denied" in o -> "izin ditolak → pakai mode Root / aktifkan Shizuku, atau tekan 🔓 Buka kunci"
            "read-only" in o -> "folder read-only → butuh mode Root"
            "no space" in o -> "penyimpanan penuh → kosongkan ruang"
            "no such file" in o -> "file/folder tidak ditemukan → tekan Diagnosa"
            else -> ""
        }
        return if (h.isEmpty()) out else "$out ($h)"
    }

    // Cek hasil inject: file hilang / berubah / rusak → timpa ulang dari daftar file
    fun checkInjected(pkg: String, entries: List<String>, root: File, files: List<File>, backupRoot: String?) {
        var okc = 0
        var fixed = 0
        var bad = 0
        for (e in entries) {
            val dst = e.substringBefore('\t')
            val want = if (e.contains('\t')) e.substringAfter('\t') else ""
            val nm = dst.substringAfterLast('/')
            if (!isSafe(dst, pkg)) continue
            val exists = sh.exec("[ -f ${q(dst)} ] && echo ya").out.contains("ya")
            val cur = if (exists) sha(dst) else ""
            if (exists && (want.isEmpty() || cur == want)) { okc++; continue }
            val src = files.firstOrNull { it.name == nm }
            if (src == null) {
                log("✗ $nm: ${if (exists) "berubah/rusak" else "hilang"}, dan file sumbernya tidak ada di daftar")
                bad++
                continue
            }
            sh.exec("chattr -i ${q(dst)} 2>/dev/null; chmod 666 ${q(dst)} 2>/dev/null")
            val r = sh.exec("cp -f ${q(src.absolutePath)} ${q(dst)} && chmod 644 ${q(dst)}")
            val now = sha(dst)
            if (r.code == 0 && (want.isEmpty() || now == want)) { log("🩹 diperbaiki: $nm"); fixed++ }
            else { log("✗ gagal memperbaiki $nm: ${hint(r.out)}"); bad++ }
        }
        log("Cek selesai: $okc normal, $fixed diperbaiki, $bad bermasalah")
    }

    fun runScript(pkg: String, dir: String, staging: String, script: String) {
        val env = "export PKG=${quote(pkg)} TARGET=${q(dir)} STAGING=${q(staging)} STORAGE=${quote(base)}; "
        val r = sh.exec(env + script)
        if (r.out.isNotBlank()) r.out.lines().forEach { log("  $it") }
        log(if (r.code == 0) "✓ Script selesai" else "✗ Script selesai dengan kode ${r.code}")
    }

    fun diagnose(pkg: String, dir: String, staging: String) {
        log("— DIAGNOSA —")
        log("id: " + sh.exec("id").out)
        log("SELinux: " + sh.exec("getenforce").out)
        log("storage terdeteksi: $base")
        log("folder staging: " + sh.exec("[ -d ${q(staging)} ] && echo ADA || echo TIDAK_ADA").out)
        log("isi staging: " + sh.exec("ls ${q(staging)} 2>&1 | head -5").out)
        log("folder tujuan: " + sh.exec("[ -d ${q(dir)} ] && echo ADA || echo TIDAK_ADA").out)
        log("isi tujuan: " + sh.exec("ls ${q(dir)} 2>&1 | head -5").out)
        log("— selesai —")
    }

    fun restore(pkg: String, dir: String, backupRoot: String) {
        if (!isSafe(dir, pkg)) { log("✗ Path ditolak: $dir"); return }
        val b = backupRoot + dir
        val chk = sh.exec("[ -d ${q(b)} ] && echo ada")
        if (!chk.out.contains("ada")) {
            log("✗ Belum ada backup untuk $dir (backup dibuat otomatis saat inject dengan opsi backup)"); return
        }
        sh.exec("chattr -i -R ${q(dir)} 2>/dev/null; chmod -R u+w ${q(dir)} 2>/dev/null")
        val r = sh.exec("cp -rf ${q("$b/.")} ${q("$dir/")}")
        log(if (r.code == 0) "✓ File asli dikembalikan ke $dir" else "✗ ${r.out}")
    }

    fun unlock(pkg: String, dir: String) {
        if (!isSafe(dir, pkg)) { log("✗ Path ditolak: $dir"); return }
        sh.exec("chattr -i -R ${q(dir)} 2>/dev/null; chmod -R u+w ${q(dir)} 2>/dev/null")
        log("🔓 Kunci dibuka di $dir")
    }

    fun clean(pkg: String, paths: List<String>) {
        for (p in paths) {
            if (!isSafe(p, pkg)) { log("✗ Ditolak: $p"); continue }
            val r = sh.exec("rm -rf ${q(p)}")
            log(if (r.code == 0) "✓ hapus $p" else "✗ $p: ${r.out}")
        }
        log("Selesai bersih-bersih")
    }
}
