package com.rootinjector.app

import android.app.Application
import com.rootinjector.app.core.CrashLog

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }
}
