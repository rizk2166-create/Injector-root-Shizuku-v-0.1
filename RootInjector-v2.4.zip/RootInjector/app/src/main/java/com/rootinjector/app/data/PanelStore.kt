package com.rootinjector.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

data class PanelDef(
    val id: String,
    val name: String,
    val target: String,
    val icon: String,
    val dirKind: String,
    val sub: String,
    val steps: String,
    val script: String,
    val files: List<File>,
    val lock: Boolean,
    val dir: File
) {
    val isBot: Boolean get() = steps.isNotBlank()
    val isInject: Boolean get() = files.isNotEmpty()
    val isScript: Boolean get() = script.isNotBlank()
}

object PanelStore {
    const val MANIFEST = "panel.json"

    const val TEMPLATE = """{
  "name": "My Panel",
  "icon": "⚡",
  "target": "com.example.game",
  "dir": "files",
  "sub": "",
  "files": ["config.ini"],
  "script": "",
  "steps": ["repeat 0", "tap 540 1200", "wait 500"]
}"""

    fun root(ctx: Context): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "injection_panels").apply { mkdirs() }

    fun list(ctx: Context): List<PanelDef> =
        (root(ctx).listFiles() ?: emptyArray())
            .filter { it.isDirectory && !it.name.startsWith(".") }
            .mapNotNull { load(it) }
            .sortedBy { it.name.lowercase() }

    fun load(dir: File): PanelDef? {
        val mf = File(dir, MANIFEST)
        if (!mf.exists()) return null
        return try {
            val j = JSONObject(mf.readText())
            val raw = j.opt("steps")
            val steps = when (raw) {
                is JSONArray -> (0 until raw.length()).joinToString("\n") { raw.getString(it) }
                is String -> raw
                else -> ""
            }
            val declared = j.optJSONArray("files")
            val all = dir.walkTopDown().filter { it.isFile && it.name != MANIFEST }.toList()
            val files = if (declared != null) {
                val names = (0 until declared.length()).map { declared.getString(it) }
                all.filter { f ->
                    val r = f.relativeTo(dir).path.replace(File.separatorChar, '/')
                    names.any { n -> n == r || n == f.name }
                }
            } else all
            PanelDef(
                dir.name, j.optString("name", dir.name), j.optString("target", ""),
                j.optString("icon", "⚡"), j.optString("dir", "files"), j.optString("sub", ""),
                steps, j.optString("script", ""), files, j.optBoolean("lock", false), dir
            )
        } catch (e: Exception) {
            null
        }
    }

    fun newDir(ctx: Context, name: String): File {
        val id = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "panel" }
        var d = File(root(ctx), id)
        var n = 2
        while (d.exists()) { d = File(root(ctx), "$id-$n"); n++ }
        d.mkdirs()
        return d
    }

    private fun looksLikeManifest(f: File): Boolean = try {
        JSONObject(f.readText()).has("name")
    } catch (e: Exception) {
        false
    }

    // tmp berisi file hasil import. Mengembalikan pesan error, atau null kalau sukses.
    fun finalize(ctx: Context, tmp: File): String? {
        val files = tmp.walkTopDown().filter { it.isFile }.toList()
        val mf = files.firstOrNull { it.name == MANIFEST }
            ?: files.firstOrNull { it.extension.lowercase() == "panel" }
            ?: files.firstOrNull { it.extension.lowercase() == "json" && looksLikeManifest(it) }
        if (mf == null) {
            tmp.deleteRecursively()
            return "No panel file found (.panel or panel.json)"
        }
        val name = try {
            JSONObject(mf.readText()).optString("name", "panel")
        } catch (e: Exception) {
            tmp.deleteRecursively()
            return "Invalid panel file: ${e.message}"
        }
        val base = mf.parentFile ?: tmp
        val target = newDir(ctx, name)
        base.copyRecursively(target, true)
        val copied = File(target, mf.name)
        if (copied.name != MANIFEST) copied.renameTo(File(target, MANIFEST))
        tmp.deleteRecursively()
        return null
    }

    fun unzip(input: InputStream, dest: File) {
        val base = dest.canonicalPath
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val out = File(dest, e.name)
                if (out.canonicalPath.startsWith(base + File.separator)) {
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { o -> z.copyTo(o) }
                    }
                }
                e = z.nextEntry
            }
        }
    }
}
