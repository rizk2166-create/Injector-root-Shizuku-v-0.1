package com.rootinjector.app.core

sealed class Cmd {
    data class Tap(val x: Int, val y: Int) : Cmd()
    data class Swipe(val x1: Int, val y1: Int, val x2: Int, val y2: Int, val ms: Int) : Cmd()
    data class Wait(val ms: Long) : Cmd()
}

class Macro(val repeat: Int, val cmds: List<Cmd>, val errors: List<String>)

object MacroParser {
    fun parse(text: String): Macro {
        var repeat = 1
        val cmds = ArrayList<Cmd>()
        val errors = ArrayList<String>()
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val p = line.split(Regex("\\s+"))
            try {
                when (p[0].lowercase()) {
                    "repeat" -> repeat = p[1].toInt()
                    "tap" -> cmds.add(Cmd.Tap(p[1].toInt(), p[2].toInt()))
                    "swipe" -> cmds.add(Cmd.Swipe(p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt(), if (p.size > 5) p[5].toInt() else 300))
                    "wait" -> cmds.add(Cmd.Wait(p[1].toLong()))
                    else -> errors.add(line)
                }
            } catch (e: Exception) {
                errors.add(line)
            }
        }
        return Macro(repeat, cmds, errors)
    }
}

class MacroRunner(
    private val sh: Shell,
    private val macro: Macro,
    private val status: (String) -> Unit
) {
    @Volatile private var running = false

    fun stop() { running = false }

    fun start() {
        if (running) return
        running = true
        Thread { loop() }.start()
    }

    private fun pause(ms: Long) {
        var left = ms
        while (running && left > 0) {
            val s = if (left > 100) 100L else left
            Thread.sleep(s)
            left -= s
        }
    }

    private fun loop() {
        var round = 0
        try {
            while (running && (macro.repeat == 0 || round < macro.repeat)) {
                round++
                for (c in macro.cmds) {
                    if (!running) break
                    when (c) {
                        is Cmd.Tap -> sh.exec("input tap ${c.x} ${c.y}")
                        is Cmd.Swipe -> sh.exec("input swipe ${c.x1} ${c.y1} ${c.x2} ${c.y2} ${c.ms}")
                        is Cmd.Wait -> pause(c.ms)
                    }
                }
                status("▶ Loop $round")
                pause(30)
            }
        } catch (e: Exception) {
            status("✗ ${e.message}")
        }
        running = false
        status("■ Stopped")
    }
}
