package com.rootinjector.app.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import androidx.documentfile.provider.DocumentFile
import com.rootinjector.app.core.ActionEngine
import com.rootinjector.app.core.Shell
import com.rootinjector.app.core.ShellProvider
import com.rootinjector.app.data.GameRepository
import com.rootinjector.app.data.PanelDef
import com.rootinjector.app.data.PanelStore
import java.io.File

class PanelActivity : Activity() {
    private lateinit var listBox: LinearLayout
    private lateinit var logView: TextView
    private lateinit var modeRoot: TextView
    private lateinit var modeShizuku: TextView
    private var useRoot = true
    private val statusViews = HashMap<String, TextView>()
    private val ext: File get() = getExternalFilesDir(null) ?: filesDir

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        useRoot = getSharedPreferences("macros", MODE_PRIVATE).getBoolean("mode_root", true)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(12), dp(16), dp(28))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BG)
        scroll.fitsSystemWindows = true
        scroll.addView(col)
        setContentView(scroll)

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = tv("⚡ Injection Panel", 24f, Ui.TEXT, true)
        title.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        val imp = btn("+ Import", 1) { showImportMenu() }
        imp.layoutParams = LinearLayout.LayoutParams(-2, -2)
        imp.setPadding(dp(18), 0, dp(18), 0)
        head.addView(title)
        head.addView(imp)
        col.addView(head)

        // mode switch
        val modeRow = LinearLayout(this)
        modeRow.orientation = LinearLayout.HORIZONTAL
        modeRow.setPadding(0, dp(10), 0, dp(4))
        modeRoot = modeChip("Root") { setMode(true) }
        modeShizuku = modeChip("Shizuku") { setMode(false) }
        modeRow.addView(modeRoot)
        modeRow.addView(modeShizuku)
        col.addView(modeRow)

        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        col.addView(listBox)

        val lc = card("LOG")
        logView = tv("", 11f, Ui.SUB)
        logView.typeface = Typeface.MONOSPACE
        logView.setTextIsSelectable(true)
        lc.addView(row(btn("Copy") { copyLog() }, btn("Clear") { logView.text = "" }))
        lc.addView(logView)
        col.addView(lc)

        updateMode()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::listBox.isInitialized) refresh()
    }

    // ---------------- UI helpers ----------------
    private fun modeChip(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(22), dp(8), dp(22), dp(8))
        t.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }
        t.setOnClickListener { onClick() }
        return t
    }

    private fun updateMode() {
        modeRoot.background = shape(if (useRoot) Ui.ACCENT else Ui.FIELD, 20)
        modeShizuku.background = shape(if (useRoot) Ui.FIELD else Ui.ACCENT, 20)
    }

    private fun setMode(root: Boolean) {
        useRoot = root
        getSharedPreferences("macros", MODE_PRIVATE).edit().putBoolean("mode_root", root).apply()
        updateMode()
    }

    private fun log(s: String) { runOnUiThread { logView.append(s + "\n") } }
    private fun toast(s: String) { runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() } }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("log", logView.text))
        toast("Log copied")
    }

    private fun refresh() {
        listBox.removeAllViews()
        statusViews.clear()
        val panels = PanelStore.list(this)
        if (panels.isEmpty()) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER_HORIZONTAL
            box.setPadding(0, dp(40), 0, dp(20))
            val e = tv("📦", 48f, Ui.TEXT)
            e.gravity = Gravity.CENTER
            val t = tv("No panels yet", 16f, Ui.SUB)
            t.gravity = Gravity.CENTER
            box.addView(e)
            box.addView(t)
            box.addView(btn("Import Panel", 1) { showImportMenu() })
            listBox.addView(box)
            return
        }
        for (p in panels) listBox.addView(panelCard(p))
    }

    private fun appIconOrEmoji(p: PanelDef): View {
        val size = dp(48)
        if (p.target.isNotBlank()) {
            try {
                val iv = ImageView(this)
                iv.setImageDrawable(packageManager.getApplicationIcon(p.target))
                iv.layoutParams = LinearLayout.LayoutParams(size, size)
                return iv
            } catch (e: Exception) { }
        }
        val t = TextView(this)
        t.text = p.icon
        t.textSize = 24f
        t.gravity = Gravity.CENTER
        t.background = shape(Ui.FIELD, 14)
        t.layoutParams = LinearLayout.LayoutParams(size, size)
        return t
    }

    private fun targetLabel(p: PanelDef): String {
        if (p.target.isBlank()) return "Choose app on run"
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(p.target, 0)).toString()
        } catch (e: Exception) {
            "${p.target} (not installed)"
        }
    }

    private fun panelCard(p: PanelDef): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = shape(Ui.CARD, 18)
        card.setPadding(dp(12), dp(12), dp(12), dp(12))
        card.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.setPadding(dp(12), 0, dp(8), 0)
        mid.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        mid.addView(tv(p.name, 16f, Ui.TEXT, true))

        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        fun addChip(text: String, color: Int) {
            val c = chip(text, color)
            c.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6); topMargin = dp(2) }
            chips.addView(c)
        }
        if (p.isBot) addChip("BOT", Color.parseColor("#7C5CFF"))
        if (p.isInject) addChip("INJECT", Ui.ACCENT)
        if (p.isScript) addChip("SCRIPT", Color.parseColor("#2FA37A"))
        mid.addView(chips)

        val st = tv(targetLabel(p), 11f, Ui.SUB)
        statusViews[p.id] = st
        mid.addView(st)

        val label = if (p.isBot && !p.isInject && !p.isScript) "Launch" else "Run"
        val run = btn(label, 1) { runPanel(p) }
        run.layoutParams = LinearLayout.LayoutParams(-2, -2)
        run.setPadding(dp(18), 0, dp(18), 0)

        card.addView(appIconOrEmoji(p))
        card.addView(mid)
        card.addView(run)
        card.setOnLongClickListener { confirmDelete(p); true }
        return card
    }

    private fun setStatus(p: PanelDef, text: String) {
        runOnUiThread { statusViews[p.id]?.text = text }
    }

    private fun confirmDelete(p: PanelDef) {
        AlertDialog.Builder(this).setTitle("Delete \"${p.name}\"?")
            .setPositiveButton("Delete") { _, _ -> p.dir.deleteRecursively(); refresh() }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------------- shell ----------------
    private fun withShell(action: (Shell) -> Unit) {
        ShellProvider.get(useRoot) { sh, err ->
            if (sh == null) log("✗ ${err ?: "Shell unavailable"}")
            else Thread {
                try { action(sh) } catch (e: Throwable) { log("✗ ${e.message}") }
            }.start()
        }
    }

    // ---------------- run ----------------
    private fun runPanel(p: PanelDef) {
        if ((p.isBot || p.isInject) && p.target.isBlank()) pickApp { pkg -> go(p, pkg) }
        else go(p, p.target)
    }

    private fun go(p: PanelDef, pkg: String) {
        if (pkg.isNotBlank() && packageManager.getLaunchIntentForPackage(pkg) == null) {
            setStatus(p, "✗ App not installed"); return
        }
        if (!p.isInject && !p.isScript) { launchBot(p, pkg); return }

        val cfg = GameRepository.loadConfig(this)
        val idx = when (p.dirKind) { "data" -> 1; "obb" -> 2; "internal" -> 3; else -> 0 }
        val t = cfg.targets[idx.coerceAtMost(cfg.targets.size - 1)]
        if (t.needsRoot && !useRoot) { setStatus(p, "✗ Needs Root mode"); return }
        var dir = t.path.replace("{pkg}", pkg)
        val sub = p.sub.trim().trim('/')
        if (sub.isNotEmpty()) dir += "/$sub"
        val backup = File(ext, "backup").absolutePath
        val manifest = File(ext, "injected/$pkg.txt")

        setStatus(p, "Running…")
        withShell { sh ->
            val eng = ActionEngine(sh, ::log)
            var ok = true
            if (p.isInject) {
                if (pkg.isNotBlank()) sh.exec("am force-stop $pkg")
                val done = eng.inject(pkg, dir, p.dir, p.files, p.lock, backup, true)
                if (done.isEmpty()) {
                    ok = false
                } else {
                    manifest.parentFile?.mkdirs()
                    val old = if (manifest.exists()) manifest.readLines() else emptyList()
                    val map = LinkedHashMap<String, String>()
                    (old + done).filter { it.isNotBlank() }.forEach { map[it.substringBefore('\t')] = it }
                    manifest.writeText(map.values.joinToString("\n") + "\n")
                }
            }
            if (p.isScript) eng.runScript(pkg, dir, p.dir.absolutePath, p.script)
            if (ok && p.isBot) runOnUiThread { launchBot(p, pkg) }
            setStatus(p, if (ok) "✓ Done" else "✗ Failed — see log")
        }
    }

    private fun launchBot(p: PanelDef, pkg: String) {
        val prefs = getSharedPreferences("macros", MODE_PRIVATE)
        prefs.edit()
            .putString("macro_$pkg", p.steps)
            .putString("name_$pkg", p.name)
            .putBoolean("root", useRoot)
            .apply()
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow \"Display over other apps\", then tap Launch again")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java)
            .putExtra("pkg", pkg)
            .putExtra("label", p.name)
            .putExtra("root", useRoot)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        setStatus(p, "✓ Panel launched")
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    private fun pickApp(cb: (String) -> Unit) {
        val all = GameRepository.installedApps(packageManager, packageName)
        var shown = all
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), 0)
        val search = edit("Search apps")
        val lv = ListView(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList(all.map { it.label }))
        lv.adapter = adapter
        box.addView(search)
        box.addView(lv, LinearLayout.LayoutParams(-1, dp(360)))
        val dialog = AlertDialog.Builder(this).setTitle("Choose app").setView(box)
            .setNegativeButton("Cancel", null).create()
        search.doAfterTextChanged {
            val k = it.toString().trim().lowercase()
            shown = all.filter { a -> a.label.lowercase().contains(k) || a.pkg.lowercase().contains(k) }
            adapter.clear()
            adapter.addAll(shown.map { a -> a.label })
        }
        lv.setOnItemClickListener { _, _, pos, _ ->
            dialog.dismiss()
            cb(shown[pos].pkg)
        }
        dialog.show()
    }

    // ---------------- import ----------------
    private fun showImportMenu() {
        val opts = arrayOf("Pick panel file(s) or .zip", "Pick folder", "Copy template")
        AlertDialog.Builder(this).setTitle("Import Panel").setItems(opts) { _, w ->
            when (w) {
                0 -> startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }, 11)
                1 -> startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 12)
                else -> {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("panel", PanelStore.TEMPLATE))
                    toast("Template copied")
                }
            }
        }.show()
    }

    private fun displayName(u: Uri): String {
        var name = "file"
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = c.getString(i)
            }
        }
        return name.replace('/', '_').replace('\\', '_')
    }

    private fun copyTree(src: DocumentFile, dst: File) {
        if (src.isDirectory) {
            dst.mkdirs()
            for (c in src.listFiles()) copyTree(c, File(dst, (c.name ?: "x").replace('/', '_')))
        } else {
            contentResolver.openInputStream(src.uri)?.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    private fun finishImport(tmp: File) {
        val err = PanelStore.finalize(this, tmp)
        if (err == null) {
            toast("Panel imported")
            runOnUiThread { refresh() }
        } else {
            toast("✗ $err")
            log("✗ Import: $err")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val tmp = File(PanelStore.root(this), ".tmp-${System.currentTimeMillis()}")
        if (requestCode == 11) {
            val uris = LinkedHashSet<Uri>()
            data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
            data.data?.let { uris.add(it) }
            Thread {
                try {
                    tmp.mkdirs()
                    for (u in uris) {
                        val name = displayName(u)
                        val input = contentResolver.openInputStream(u) ?: continue
                        input.use {
                            if (name.lowercase().endsWith(".zip")) PanelStore.unzip(it, tmp)
                            else File(tmp, name).outputStream().use { o -> it.copyTo(o) }
                        }
                    }
                    finishImport(tmp)
                } catch (e: Exception) {
                    tmp.deleteRecursively()
                    toast("✗ Import failed: ${e.message}")
                }
            }.start()
        } else if (requestCode == 12) {
            val tree = data.data ?: return
            Thread {
                try {
                    tmp.mkdirs()
                    val d = DocumentFile.fromTreeUri(this, tree)
                    if (d != null) copyTree(d, tmp)
                    finishImport(tmp)
                } catch (e: Exception) {
                    tmp.deleteRecursively()
                    toast("✗ Import failed: ${e.message}")
                }
            }.start()
        }
    }
}
