Folder contoh. Ganti nama folder jadi package name app target.
